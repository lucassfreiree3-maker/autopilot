# Changelog

Formato baseado em [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [2.0.8] - 02-14-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Adiciona interpretação no campo ``enabled`` para permitir enabled condicional.  

## [2.0.7] - 02-13-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Adiciona action `replaceValueWithDirectMap` que permite a escrita do map diretamente na "chamada" da action.  

## [2.0.6] - 02-13-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Adiciona definição ``tplvalues.render``, originalmente presente como dependência do chart ``Bitnami Common Library Chart``.  

## [2.0.5] - 02-10-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Adiciona validação de inputs.  

## [2.0.4] - 02-10-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Adiciona campo '_preserveCondition' nos itens de array para possibilitar a exclusão de item na lista final caso a condição definida não seja satisfeita.  

## [2.0.3] - 02-10-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Template 'generico.execMap' para poder executar map dentro de map.  

## [2.0.2] - 01-23-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adiionado
- Actions podem ser interpretadas dentro de arrays.  

## [2.0.1] - 01-21-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Fix
- Falta de quebra de linha causando "block sequence entries are not allowed in this context".  
- Campo 'enabled' aparecendo no objeto final.  

## [2.0.0] - 01-17-2024 [@F7002537](https://fontes.intranet.bb.com.br/f7002537)
# Adicionado
- Possibilidade de fazer o parse de 'strings json' presentes no `.Values.global` através do objeto `listaDeStringsJsonParaInjetarNoValuesGlobal`.
- Adiciona interpretador de `actions`. 

## [1.0.2] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)
# fix
- Fix values.yaml default.

## [1.0.1] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)
# fix
- Remoção das quotes que estavam ficando nas labels

## [1.0.0] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)
# Modificado
- Incluída a previsão de uso de variáveis globais.
- fix no tratamento das labels. Ficava um espaço em branco quando ia rederizar.
