{{/* funcoes.validaCamposObjeto._converterTipoParaNomeAmigavel */}}
{{- define "funcoes.validaCamposObjeto._converterTipoParaNomeAmigavel" -}}
{{- $tipo := .tipo -}}
{{/*- fail (printf "tipo: %v" $tipo) -*/}}
{{- if eq $tipo "float64" -}}
number
{{- end -}}
{{- if eq $tipo "map[string]interface {}" -}}
object
{{- end -}}
{{- if eq $tipo "[]interface {}" -}}
list
{{- end -}}
{{- if eq $tipo "string" -}}
string
{{- end -}}
{{- if eq $tipo "bool" -}}
bool
{{- end -}}
{{- end -}}

{{/*
funcoes.validaCamposObjeto

DESCRIÇÃO
Valida um objeto usando um schema de validação (1).

INPUT
.data - <object> os valores a serem validados
.validationsList - <object> o schema de validação

OUTPUT (em json - deve ser parseado)
  result:
    code: <int> número com sentido interno da função para facilitar a depuração
    ok: <bool> true, caso o objeto seja válido; false, no caso contrário
    msg: <string> descrição do retorno

---

(1) schema de validação
EXEMPLO 1:
validationsList:
  campo_a:
    type: string

EXEMPLO 2:
validationsList:
  campo_a:
    type: bool

EXEMPLO 3:
validationsList:
  campo_a:
    type: number

EXEMPLO 4:
validationsList:
  campo_a:
    type: list
    items:
      type: string

EXEMPLO 5:
validationsList:
  campo_a:
    type: object
    fields:
      campo_b:
        type: string
      campo_c:
        type: bool
      campo_d:
        type: number
*/}}
{{- define "funcoes.validaCamposObjeto" -}}
{{- $nomeFuncaoValidaCamposObjeto := "funcoes.validaCamposObjeto" -}}

{{- $data := .data -}}
{{- $validationsList := .validationsList -}}

{{- if not $data -}}
{{/*- fail (printf "Erro na função '%v': .data obrigatório, mas não encontrado." $nomeFuncaoValidaCamposObjeto) -*/}}
{{- end -}}

{{- $dataType := printf "%T" $data -}}

{{- if eq $dataType "chartutil.Values" -}}
{{- $dataType = "map[string]interface {}" -}}
{{- end -}}

{{- if ne $dataType "map[string]interface {}" -}}
{{- fail (printf "Erro na função '%v': .data deve ser um objeto (encontrado: %v)." $nomeFuncaoValidaCamposObjeto $dataType) -}}
{{- end -}}

{{- if not $validationsList -}}
{{/*- fail (printf "Erro na função '%v': .validationsList obrigatório, mas não encontrado." $nomeFuncaoValidaCamposObjeto) -*/}}
{{- end -}}

{{- $validationsListType := printf "%T" $validationsList -}}

{{- if eq $validationsListType "chartutil.Values" -}}
{{- $validationsListType = "map[string]interface {}" -}}
{{- end -}}

{{- if ne $validationsListType "map[string]interface {}" -}}
{{- fail (printf "Erro na função '%v': .validationsList deve ser um objeto (encontrado: %v)." $nomeFuncaoValidaCamposObjeto $validationsListType) -}}
{{- end -}}

{{/*- fail (printf "\n\nvzzalidationsList: %v\n\n---\n\ndata: %v\n" $validationsList $data) -*/}}

{{- $resultCode := 131 -}}
{{- $resultOk := true -}}
{{- $resultMsg := "Dados validados com sucesso." -}}

{{- $nomes := list -}}

{{- range $nomeCampo, $schema := $validationsList -}}

  {{- if eq (printf "%T" $schema) "string" -}}
    {{- fail (printf "nomeCampo: %v" $nomeCampo) -}}
  {{- end -}}

  {{- if eq $resultOk true -}}
    {{/*- fail "L80" -*/}}

    {{- $itemExiste := false -}}
    {{- $itemEhRequired := true -}}

    {{- $nomes = append $nomes $nomeCampo -}}

    {{- if hasKey $data $nomeCampo -}}
      {{- $itemExiste = true -}}
      {{/*- fail "l84" -*/}}
    {{- end -}}

    {{- if hasKey $schema "required" -}}
      {{- $itemEhRequired = $schema.itemEhRequired -}}
      {{/*- fail "l89" -*/}}
    {{- end -}}

    {{- $typeSchema := $schema.type -}}

    {{- if not $typeSchema -}}
      {{- $resultCode = 159 -}}
      {{- $resultOk = false -}}
      {{- $resultMsg = (printf "O campo .type é obrigatório." $nomeCampo) -}}
    {{- end -}}

    {{- $itemNaoExisteMasEhRequired := and $itemEhRequired (not $itemExiste) -}}
    
    {{/*
    V F = TRUE
    V V = F
    F V = F
    F F = F
    */}}
    {{- if $itemNaoExisteMasEhRequired -}}
      {{- $resultCode = 173 -}}
      {{- $resultOk = false -}}
      {{- $resultMsg = (printf "O campo '%v' é obrigatório, mas não foi encontrado." $nomeCampo) -}}
    {{- else -}}
      {{- if $itemExiste -}}
        {{- $valorCampo := (get $data $nomeCampo) -}}

        {{- if eq $typeSchema "object" -}}

          {{- $fieldsSchema := $schema.fields -}}

          {{- if not $fieldsSchema -}}
            {{- $resultCode = 184 -}}
            {{- $resultOk = false -}}
            {{- $resultMsg = (printf "O campo .fields é obrigatório." $nomeCampo) -}}
          {{- end -}}

          {{/*- fail (printf "fieldsSchema: %v" $fieldsSchema) -*/}}
          {{/*- fail (printf "valorCampo: %v" $valorCampo) -*/}}

          {{- $validaObject := include $nomeFuncaoValidaCamposObjeto (dict "data" $valorCampo "validationsList" $fieldsSchema) -}}
          {{- $resultValidaObject := (fromJson $validaObject).result -}}

          {{/*- fail (printf "\n\ndata: %v\n\n\nvalidationsList: %v\n" (get $data $nomeCampo) $fieldsSchema) -*/}}
          {{/*- fail (printf "\n\ndata: %v\n\n\nvalidationsList: %v\n" $data $validationsList) -*/}}
          {{/*- fail (printf "resultValidaObject: %v" $resultValidaObject) -*/}}

          {{- $resultCode = $resultValidaObject.code -}}
          {{- $resultOk = $resultValidaObject.ok -}}
          {{- $resultMsg = $resultValidaObject.msg -}}

        {{- else -}}
          {{- if eq $typeSchema "list" -}}

            {{- $items := $schema.items -}}

            {{- if not $items -}}
              {{- $resultCode = 211 -}}
              {{- $resultOk = false -}}
              {{- $resultMsg = (printf ".items necessário") -}}
            {{- else -}}

              {{- $tipoValorCampo := printf "%T" $valorCampo -}}

              {{- if ne $tipoValorCampo "[]interface {}" -}}
                {{- $resultCode = 220 -}}
                {{- $resultOk = false -}}

                {{- if and (ne $tipoValorCampo "string") (ne $tipoValorCampo "bool") -}}
                  {{- $tipoValorCampo = include "funcoes.validaCamposObjeto._converterTipoParaNomeAmigavel" (dict "tipo" $tipoValorCampo) -}}
                {{- end -}}

                {{- $resultMsg = (printf "O campo '%v' tem o tipo '%v', mas deve ser do tipo '%v'." $nomeCampo $tipoValorCampo "list") -}}
              {{- else -}}

                {{- range $_, $itemLista := $valorCampo -}}

                  {{- if eq $items.type "object" -}}

                    {{- $validationsList2 := dict -}}
                    {{- $_ := set $validationsList2 $nomeCampo $items -}}

                    {{- if ne (printf "%T" $itemLista) "map[string]interface {}" -}}
                      {{- $resultCode = 238 -}}
                      {{- $resultOk = false -}}
                      {{- $resultMsg = printf "Os itens do campo '%v' devem ser objetos." $nomeCampo -}}
                    {{- else -}}
                      {{- $validaObject := include $nomeFuncaoValidaCamposObjeto (dict "data" $itemLista "validationsList" $items.fields) -}}
                      {{- $resultValidaObject := (fromJson $validaObject).result -}}

                      {{- $resultCode = $resultValidaObject.code -}}
                      {{- $resultOk = $resultValidaObject.ok -}}
                      {{- $resultMsg = $resultValidaObject.msg -}}
                    {{- end -}}

                  {{- else -}}
                    {{- if or (eq $items.type "bool") (eq $items.type "string") (eq $items.type "number") -}}

                      {{- $tipoItemLista := printf "%T" $itemLista -}}
                      {{- $tipoItemListaAmigavel := include "funcoes.validaCamposObjeto._converterTipoParaNomeAmigavel" (dict "tipo" $tipoItemLista) -}}

                      {{- if not (eq $items.type $tipoItemListaAmigavel) -}}
                        {{- $resultCode = 257 -}}
                        {{- $resultOk = false -}}
                        {{- $resultMsg = printf "Os itens da lista devem ser todos %v, mas um deles é %v." $items.type $tipoItemListaAmigavel -}}
                      {{- end -}}

                    {{- end -}}
                  {{- end -}}

                {{- end -}}

              {{- end -}}          

            {{- end -}}

          {{- else -}}
            {{/* $typeSchema deve ser um dos seguintes: number, string, bool */}}

            {{- if or (eq $typeSchema "string") (eq $typeSchema "number") (eq $typeSchema "bool") -}}

              {{- $tipoValorCampo := printf "%T" $valorCampo -}}

              {{- if and (ne $tipoValorCampo "string") (ne $tipoValorCampo "bool") -}}
                {{- $tipoValorCampo = include "funcoes.validaCamposObjeto._converterTipoParaNomeAmigavel" (dict "tipo" $tipoValorCampo) -}}
              {{- end -}}

              {{/*- fail (printf "tipoValorCampo: %v" $tipoValorCampo) -*/}}

              {{- $tiposSaoDiferentes := not (eq $typeSchema $tipoValorCampo) -}}

              {{- if $tiposSaoDiferentes -}}
                {{- $resultCode = 288 -}}
                {{- $resultOk = false -}}
                {{- $resultMsg = (printf "O campo '%v' tem o tipo '%v', mas deve ser do tipo '%v'." $nomeCampo $tipoValorCampo $typeSchema) -}}
              {{- end -}}

            {{- end -}}
          {{- end -}}

        {{- end -}}

      {{- end -}}
    {{- end -}}

  {{- end -}}
{{- end -}}

{{/*- fail (printf "nomes: %v" $nomes) -*/}}

{{- $output := dict -}}
{{- $output := set $output "result" dict -}}

{{- $result := get $output "result" -}}

{{- $_ := set $result "code" $resultCode -}}
{{- $_ := set $result "ok" $resultOk -}}
{{- $_ := set $result "msg" $resultMsg -}}

{{- toJson $output -}}

{{- end -}}
