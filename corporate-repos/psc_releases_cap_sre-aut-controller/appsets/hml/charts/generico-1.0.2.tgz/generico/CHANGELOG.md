# Changelog

Formato baseado em [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).


## [1.0.2] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)

# fix
- Fix values.yaml default.

## [1.0.1] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)

# fix
- Remoção das quotes que estavam ficando nas labels

## [1.0.0] - 06-07-2023 [@F5829253](https://fontes.intranet.bb.com.br/f8368354)

# Modificado
- Incluída a previsão de uso de variáveis globais.
- fix no tratamento das labels. Ficava um espaço em branco quando ia rederizar.

