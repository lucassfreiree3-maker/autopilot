# Chart genérico
Chart que gera uma lista de objetos kubernetes.

## Por que usar?
Diferente do funcionamento padrão, o `values.yaml` desse chart possibilita o uso e modificação de valores dinâmicos.

## Funcionamento básico
A lista final é renderizada a partir de um array de objetos chamado `items`.

Exemplo:
```yaml
items:
- enabled: true

  apiVersion: v1
  kind: Namespace
  metadata:
    labels: 
      release.k8s.bb/sigla: psc
    name: operator-2025

- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: kube-root-ca.crt
    namespace: teste
  data:
    ca.crt: |
      << CERTIFICADO >>
```

## Valores dinâmicos
É possível colocar 'placeholders' nos valores dos campos, que serão renderizados pelo Helm.  

Exemplo:  

input:  
```yaml
global:
  ambiente: des
  url: metrics.bb.com.br
  aceitaConexoesExternas: false
```

values.yaml  
```yaml
items:
- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: "connection-{{ .Values.global.ambiente }}"
    namespace: teste
  data:
    url: "{{ .Values.global.url }}"
    ambiente: "{{ .Values.global.ambiente }}"
    aceitaConexoesExternas: "{{ .Values.global.aceitaConexoesExternas }}"
```

Manifesto gerado:  
```yaml
- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: "connection-des"
    namespace: teste
  data:
    url: "metrics.bb.com.br"
    ambiente: "des"
    aceitaConexoesExternas: "false" # deixou de ser booleano
```

**Limitação**: os 'placeholders' só funcionam se colocados em uma string, dessa forma, mesmo que o valor de entrada seja de um tipo diferente de string, o campo será uma string após a renderização.  

## Actions
Para lídar com limitações, como a descrita na seção acima, foi incluiído no chart um interpretador simples de actions.  

A sintaxe é da seguinte forma:
```yaml
campo: "NOME_ACTION valor_qualquer"
```

Exemplo:
input:  
```yaml
global:
  ambiente: des
  url: metrics.bb.com.br
  aceitaConexoesExternas: false
```

values.yaml  
```yaml
- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: "connection-des"
    namespace: teste-bool
  data:
    aceitaConexoesExternas: "makeItBool {{ .Values.global.aceitaConexoesExternas }}"
```

Manifesto gerado:  
```yaml
- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: "connection-des"
    namespace: teste-bool
  data:
    aceitaConexoesExternas: false # convertido para booleano
```

### Lista de actions

| NOME_ACTION | Descrição | 
|-------------|:----------|
| makeItBool | Transforma o valor em booleano. |
| makeItNumber | Transforma o valor em number. |
| replaceValueWith | Define o valor para o input especificado. |
| replaceValueWithMap |  Define o valor para o valor do map especificado. |
| replaceValueWithDirectMap |  Define o valor para o valor do map especificado na própria definição do campo. |

#### replaceValueWith

Exemplo:  

input de dados:
```yaml
global:
  listaUrls:
  - https://www.google.com/
  - http://microsoft365.com/
  - https://fontes.intranet.bb.com.br/
```

values.yaml  
```yaml
items:
- enabled: true

  apiVersion: v1
  kind: ConfigMap
  metadata:
    annotations:
      kubernetes.io/description: bla bla bla
    name: "connection-des"
    namespace: teste-bool
  data:
    listaUrls: "replaceValueWith {{ .Values.global.listaUrls }}"
```

Manifesto gerado:  
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  annotations:
    kubernetes.io/description: bla bla bla
  name: "connection-des"
  namespace: teste-bool
data:
  listaUrls:
  - https://www.google.com/
  - http://microsoft365.com/
  - https://fontes.intranet.bb.com.br/
```

#### replaceValueWithMap

Map é a definição de um template.  

Eles estão definidos dentro do array chamado `_Maps` e cada um deles deve possuir um objeto com o nome do mapa.  

Exemplo:

Map
```yaml
_Maps:
  destinations: |-
    destinations:
      - namespace: "{{ printf "%v-%v" .Values.global.capacidade.sigla .Values.global.capacidade.nome }}"
        server: "*"
```

Input
```yaml
global:
  capacidade:
    nome: cap1
    sigla: psc
```

Uso do map:
```yaml
items:
- enabled: true

  apiVersion: argoproj.io/v1alpha1
  kind: AppProject
  metadata:
    name: 'interno'
    namespace: "util"
      
    labels:
      capacidade.k8s.bb/nome: "cap1"
      capacidade.k8s.bb/sigla: "psc"
  spec:
    destinations: "replaceValueWithMap destinations"

```

Manifesto gerado:
```yaml
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: 'interno'
  namespace: "util"
    
  labels:
    capacidade.k8s.bb/nome: "cap1"
    capacidade.k8s.bb/sigla: "psc"
spec:
  destinations:
  - namespace: "psc-cap1"
    server: "*"
```

#### replaceValueWithDirectMap

Exemplo:

Input
```yaml
global:
  namespaceDoArgo: infra-util
```

values  
```yaml
items:
- 
  enabled: true

  kind: Application
  metadata:
    name: 'psc-teste-app-infradedicada'
    namespace: '{{ .Values.global.namespaceDoArgo }}'
  spec:
    destination: |
      replaceValueWithDirectMap
      destination:
        namespace: '{{ .Values.global.namespaceDoArgo }}'
        server: https://kubernetes.default.svc

    project: default

    syncPolicy:
      automated:
        allowEmpty: true
        prune: true
        selfHeal: true
```

Manifesto gerado:
```yaml
kind: Application
metadata:
  name: 'psc-teste-app-infradedicada'
  namespace: infra-util
spec:
  destination:
    namespace: infra-util
    server: https://kubernetes.default.svc

  project: default

  syncPolicy:
    automated:
      allowEmpty: true
      prune: true
      selfHeal: true
```

## _preserveCondition

Em itens de array que são objetos, é possível omiti-los condicionalmente usando o campo `_preserveCondition`.

Exemplo:  

input:  
```yaml
global:
  permitirNodesDedicados: true
```

values:  
```yaml
items:
  - 
    apiVersion: argoproj.io/v1alpha1
    kind: ApplicationSet
    metadata:
      name: 'appset-teste'
      namespace: 'psc-teste'
    spec:
      sources:
      # nodesDedicados
      - _preserveCondition: '{{ eq .Values.global.permitirNodesDedicados true }}'
      
        targetRevision: HEAD
        repoURL: "{{ .Values.global.repoUrl }}"
        path: "nodesDedicados"
        helm:
          valueFiles:
            - values.yaml
```

Nesse caso, o source de nodes dedicados só será considerado se a variável permitirNodesDedicados for verdadeira.  
