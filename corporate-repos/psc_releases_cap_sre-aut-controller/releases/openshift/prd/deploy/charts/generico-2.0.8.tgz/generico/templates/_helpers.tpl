{{/*
Expand the name of the chart.
*/}}
{{- define "generico.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "generico.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "generico.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "generico.labels" -}}
helm.sh/chart: {{ include "generico.chart" . }}
release.k8s.bb/chart-name-original: generico
release.k8s.bb/chart-version: {{ .Chart.Version }}
{{ include "generico.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "generico.selectorLabels" -}}
app.kubernetes.io/name: {{ include "generico.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "generico.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "generico.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
generico.injectJsonStringsIntoGlobalValues

DESCRIÇÃO:
Faz o parse de strings json e injeta o parsed object no objeto .Values.global.

INPUT:
root - objeto do escopo global ($)
*/}}
{{- define "generico.injectJsonStringsIntoGlobalValues" -}}
{{- $root := .root -}}
{{- $global := $root.Values.global -}}
{{- $list := $root.Values.listaDeStringsJsonParaInjetarNoValuesGlobal -}}

{{- if $list -}}
{{- range $stringJson := $list -}}
  {{- if hasKey $global $stringJson -}}
    {{- $item := get $global $stringJson -}}
    {{- if eq (typeOf $item) "string" -}}
      {{- $_ := set $global $stringJson (merge (fromJson $item) (dict "json" $item)) -}}
    {{- else -}}
      {{- if hasKey $item "json" -}}
        {{- $json := $item.json -}}
        {{- $_ := set $global $stringJson (merge (fromJson $json) (dict "json" $json)) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- end -}}

{{- define "generico._action.makeItBool" -}}
{{- $manifestoFinal := .manifestoFinal -}}
{{- $context := .context -}}

{{- $action := .action -}}
{{- $actionData := .actionData -}}

{{- $nomeCampo := .nomeCampo -}}
{{- $valorCampo := .valorCampo -}}

{{/*- fail (printf "%v" $valorCampo) -*/}}
{{- if eq $actionData "true" -}}
novoValor: true
{{- else -}}
novoValor: false
{{- end -}}
{{- end -}}

{{- define "generico._action.makeItNumber" -}}
{{- $manifestoFinal := .manifestoFinal -}}
{{- $context := .context -}}

{{- $action := .action -}}
{{- $actionData := .actionData -}}

{{- $nomeCampo := .nomeCampo -}}
{{- $valorCampo := .valorCampo -}}

novoValor: {{ float64 $actionData }}
{{- end -}}

{{- define "generico._action.replaceValueWith" -}}
{{- $manifestoFinal := .manifestoFinal -}}
{{- $context := .context -}}

{{- $action := .action -}}
{{- $actionData := .actionData -}}

{{- $nomeCampo := .nomeCampo -}}
{{- $valorCampo := .valorCampo -}}

{{/*- fail (printf "%v" $manifestoFinal) -*/}}

novoValor: {{ $actionData }}
{{- end -}}

{{- define "generico._action.replaceValueWithMap" -}}
{{- $manifestoFinal := .manifestoFinal -}}
{{- $context := .context -}}

{{- $action := .action -}}
{{- $actionData := .actionData -}}

{{- $nomeCampo := .nomeCampo -}}
{{- $valorCampo := .valorCampo -}}

{{/*- fail (printf "%v" $manifestoFinal) -*/}}

{{- $_Maps := $context.Values._Maps -}}

{{- if not (hasKey $_Maps $actionData) -}}
novoValor: L159
{{- else -}}
  {{- $map := get $_Maps $actionData -}}
  {{- $render := tpl $map $context -}}

  {{- $renderYaml := (fromYaml $render) -}}
  {{- $value := get $renderYaml $actionData -}}

  {{- $yaml := dict -}}
  {{- $_ := set $yaml "novoValor" $value -}}

{{/*- fail (printf "%v" $renderYaml) -*/}}

{{ toYaml $yaml }}
{{- end -}}
{{- end -}}

{{- define "generico._action.replaceValueWithDirectMap" -}}
{{- $manifestoFinal := .manifestoFinal -}}
{{- $context := .context -}}

{{- $action := .action -}}
{{- $actionData := .actionData -}}

{{- $nomeCampo := .nomeCampo -}}
{{- $valorCampo := .valorCampo -}}

{{/*- fail (printf "%v" $manifestoFinal) -*/}}

{{- $map := $actionData -}}
{{- $render := tpl $map $context -}}

{{/*- fail (printf "%v" $map) -*/}}

{{- $renderYaml := (fromYaml $render) -}}
{{/*- fail (printf "%v" $renderYaml) -*/}}

{{- $value := get $renderYaml $nomeCampo -}}
{{/*- fail (printf "%v" $value) -*/}}

{{- $yaml := dict -}}
{{- $_ := set $yaml "novoValor" $value -}}

{{/*- fail (printf "%v" $renderYaml) -*/}}
{{ toYaml $yaml }}
{{- end -}}

{{/*
generico.interpretaActions

DESCRIÇÃO:

USAGE
include "generico.interpretaActions" ( dict "value" . "context" $ )
*/}}
{{- define "generico.interpretaActions" -}}
{{- $value := .value -}}
{{- $context := .context -}}

{{- $manifesto := fromYaml $value -}}

{{- $manifestoFinal := dict -}}
{{- $tipoObjeto := "map[string]interface {}" -}}
{{- $tipoArray := "[]interface {}" -}}

{{- range $nomeCampo, $valorCampo := $manifesto -}}
  {{- if eq (typeOf $valorCampo) "string" -}}
    {{- $partesString := splitList " " $valorCampo -}}

    {{- $partesLen := len $partesString -}}

    {{/* Achar uma forma melhor de fazer isso */}}
    {{- if or (eq $partesLen 2) -}}
      {{- $action := index $partesString 0 -}}
      {{- $actionData := index $partesString 1 -}}

      {{- $actionPayload := dict "context" $context "manifestoFinal" $manifestoFinal "action" $action "actionData" $actionData "nomeCampo" $nomeCampo "valorCampo" $valorCampo -}}
      {{- $novoValor := include (printf "generico._action.%s" $action) $actionPayload -}}

      {{- $valorCampo = (fromYaml $novoValor).novoValor -}}
    {{- else if (hasPrefix "replaceValueWithDirectMap" $valorCampo) -}}
      {{- $partesString := splitList "\n" $valorCampo -}}

      {{- $action := index $partesString 0 -}}
      {{- $actionData := trimPrefix "replaceValueWithDirectMap" $valorCampo -}}

      {{- $actionPayload := dict "context" $context "manifestoFinal" $manifestoFinal "action" $action "actionData" $actionData "nomeCampo" $nomeCampo "valorCampo" $valorCampo -}}
      {{- $novoValor := include (printf "generico._action.%s" $action) $actionPayload -}}

      {{- $valorCampo = (fromYaml $novoValor).novoValor -}}
    {{- end -}}

    {{- $_ := set $manifestoFinal $nomeCampo $valorCampo -}}
  {{- else -}}

    {{- if eq (typeOf $valorCampo) $tipoObjeto -}}
      {{- $_ := set $manifestoFinal $nomeCampo (fromYaml (include "generico.interpretaActions" (dict "value" (toYaml $valorCampo) "context" $context))) -}}
    {{- else if eq (typeOf $valorCampo) $tipoArray -}}

      {{- $novaLista := list -}}

      {{- range $nomeArray, $valorArray := $valorCampo -}}

        {{- if eq (typeOf $valorArray) $tipoObjeto -}}
          {{- $conditionKeyName := "_preserveCondition" -}}
          {{- if hasKey $valorArray $conditionKeyName -}}
            {{/*- $_condition := tpl $valorArray._condition $context -*/}}
            {{- $_condition := get $valorArray $conditionKeyName -}}
            {{- $_ := unset $valorArray $conditionKeyName -}}
            {{/*- fail (printf "%v" $_condition) -*/}}
            {{- if eq $_condition "true" -}}
              {{- $novaLista = append $novaLista (fromYaml (include "generico.interpretaActions" (dict "value" (toYaml $valorArray) "context" $context))) -}}
            {{- end -}}
          {{- else -}}
            {{- $novaLista = append $novaLista (fromYaml (include "generico.interpretaActions" (dict "value" (toYaml $valorArray) "context" $context))) -}}
          {{- end -}}

          {{/*- fail (printf "%v" $valorArray) -*/}}
        {{- else -}}
          {{- $novaLista = append $novaLista $valorArray -}}
        {{- end -}}
  
      {{- end -}}

      {{- $_ := set $manifestoFinal $nomeCampo $novaLista -}}

    {{- else -}}
      {{- $_ := set $manifestoFinal $nomeCampo $valorCampo -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- toYaml $manifestoFinal -}}
{{- end -}}

{{/*
generico.render

DESCRIÇÃO
Renderiza o manifesto final do item presente na lista de items.

USAGE
include "generico.render" ( dict "value" . "context" $ )
*/}}
{{- define "generico.render" -}}
{{- $value := .value -}}
{{- $context := .context -}}

{{- $commonRenderValue := include "tplvalues.render" ( dict "value" $value "context" $context ) -}}

{{- include "generico.interpretaActions" ( dict "value" $commonRenderValue "context" $context ) -}}

{{/*- $commonRenderValue -*/}}
{{- end -}}

{{/*
generico.execMap

DESCRIÇÃO
Renderiza um map dado um nome e um contexto (dict).

EXEMPLO DE USO
template "generico.execMap" (dict "map" "generatorsList" "context" .)
*/}}
{{- define "generico.execMap" -}}
  {{- $mapName := .map -}}
  {{- $context := .context -}}

  {{- $_Maps := $context.Values._Maps -}}

  {{- $map := get $_Maps $mapName -}}
  {{- $render := tpl $map $context -}}

  {{- $renderYaml := (fromYaml $render) -}}
  {{- $value := get $renderYaml $mapName -}}

  {{- toJson $value -}}
{{- end -}}

{{/*
generico.execMap

DESCRIÇÃO
Valida os valores de entrada.
*/}}
{{- define "generico.validaInput" -}}
{{- $root := .root -}}

{{- $data := $root.Values -}}
{{- $validationsList := $root.Values.validationsList -}}

{{- $resultadoString := include "funcoes.validaCamposObjeto" (dict "data" $data "validationsList" $validationsList) -}}
{{- $resultado := (fromJson $resultadoString).result -}}

{{- if ne $resultado.ok true -}}
{{- fail (printf "Erro na validação dos dados de input: %v" $resultado.msg) -}}
{{- end -}}

{{- end -}}
