# Changelog

Formato baseado em [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [0.0.2] - 02-10-2025 [@f7002537](https://fontes.intranet.bb.com.br/f7002537)
# Modificado
- Modifica o tipo dos inputs quando tipo for chartutil.Values para considerar o uso da função no objeto .Values.    

## [0.0.1] - 12-19-2024 [@f7002537](https://fontes.intranet.bb.com.br/f7002537)
# 0.0.1
- Versão inicial do ``funcaoValidaObjeto``.
