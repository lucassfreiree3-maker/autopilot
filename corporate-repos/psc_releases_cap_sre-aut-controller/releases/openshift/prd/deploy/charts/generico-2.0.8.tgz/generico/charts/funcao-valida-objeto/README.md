# Chart funcao-valida-objeto

O chart possui a definição `funcoes.validaCamposObjeto` que valida objetos usando um schema de validação.

## Importação no chart

```yaml
dependencies:
  - name: funcao-valida-objeto
    version: 0.0.1
    repository: https://charts-repo.nuvem.bb.com.br/pre-prd/bb/psc
```

## Parâmetros

**Input**  
É esperado um ``dict`` com um campo data, que é o objeto a ser validado, e um campo validationsList, que é o schema de validação.

```yaml
validationsList:
  campo_a:
    type: string
  campo_b:
    type: bool
  campo_c:
    type: number
  campo_d:
    type: object
    fields: {}
  campo_e:
    type: list
    items:
      type: string
```

Cada campo do objeto **validationsList** define o tipo esperado para o campo especificado.

**Output**  
Retorna uma string json, que **deve ser 'parseada'** usando o comando `fromJson`, com a seguinte estrutura:
```json
{
  "result": {
    "code": int,
    "ok": bool,
    "msg": "string"
  }
}
```

| Variável             | Tipo                                          | Descrição                                 |
|-------------------------------|------------------------------------------------------|------------------------------------------------|
| `result.code`  | int                 | Valor com sentido interno da função para facilitar a depuração.  |
| `result.ok`  | bool                 | ``true``, se o objeto for válido; ``false``, no caso contrário.  |
| `result.msg`  | string                 | Descrição do retorno.  |

## Exemplo de uso

Esse exemplo busca explorar os principais usos de caso de validação realizados pela definição `funcoes.validaCamposObjeto`.  

Considere que desejamos validar o objeto seguinte:

```yaml
data:
  a: abc
  b: false
  c: 123
  d:
    e: qwe
    f: true
    g: 321
  h:
  - white
  - red
  - blue
  i:
    j:
    - 1
    - 2
    - 3
    k:
      l:
      - a
      - b
      - c
      m:
      - 1
      - 2
      - 3
      n:
        o: p
        r: s
        t: 89
        u: false
  s:
  - a: 1
    b: "green"
  - a: 3
    b: "red"
```

Para isso, utilizamos o schema de validação:
```yaml
validationsList:
  a:
    type: string
  b:
    type: bool
  c:
    type: number
  d:
    type: object
    fields:
      e:
        type: string
      f: 
        type: bool
      g: 
        type: number
  h:
    type: list
    items:
      type: string
  
  i:
    type: object
    fields:
      j:
        type: list
        items:
          type: number
      k:
        type: object
        fields:
          l:
            type: list
            items:
              type: string
          m:
            type: list
            items:
              type: number
          n:
            type: object
            fields:
              o:
                type: string
              r:
                type: string
              t:
                type: number
              u:
                type: bool

  s:
    type: list
    items:
      type: object
      fields:
        a:
          type: number
        b:
          type: string
```

Execução da definção:
```yaml
{{- $resultadoString := include "funcoes.validaCamposObjeto" (dict "data" $data "validationsList" $validationsList) -}}
{{- $resultado := (fromJson $resultadoString).result -}}
{{- if $resultado.ok -}}
  ## 
{{- end -}}
```

## Testes
Link: [https://fontes.intranet.bb.com.br/psc/helm_charts/psc-chart-testes-funcao-valida-objeto/-/tree/master](https://fontes.intranet.bb.com.br/psc/helm_charts/psc-chart-testes-funcao-valida-objeto/-/tree/master)
